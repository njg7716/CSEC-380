<!DOCTYPE html>
<html lang="en">
	<head>
	</head>
	<body>
	<a href="http://csec380-core.csec.rit.edu:84/add_friend.php?id=36">link
	</a>
	</body>
</html>
